javac *.java
jar cfm my-new-game.jar Manifest.txt *.class
rm *.class
